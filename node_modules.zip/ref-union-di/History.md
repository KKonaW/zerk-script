
1.0.1 / 2015-12-27
==================

  * test node v5
  * package: more lenient "bindings" version
  * package: add "license" field
  * package: add a few more keywords
  * README: use SVG for AppVeyor badge

1.0.0 / 2015-10-02
==================

  * bumping to v1.0.0 for better-defined semver semantics

0.0.4 / 2015-10-02
==================

  * moar tests
  * update deps and tests for nan v2 / node.js v4

0.0.3 / 2014-06-19
==================

  * package: update all dependencies
  * test: nan-ify native tests
  * package: loosely pin deps
  * README: add appveyor build badge
  * README: use svg for Travis badge
  * travis: test node v0.8, v0.10, and v0.11
  * add appveyor.yml file
  * pacakge: remove "engines" field
  * package: beautify
  * rename the backing buffer property to "ref.buffer"
  * move the exports to the top
  * test: yet another test
  * test: add another native test
  * test: add a couple more native tests
  * test: use "node-bindings" to load the test native bindings
