const ffi = require('ffi-napi');
const ref = require('ref-napi');
const di_struct = require('ref-struct-di');
const struct = di_struct(ref);
const union_di = require('ref-union-di');
const union = union_di(ref);
const keycodes = require('./keycodes.js');

const MOUSEINPUT = struct({
	dx: 'int32',
	dy: 'int32',
	mouseData: 'uint32',
	dwFlags: 'uint32',
	time: 'uint32',
	dwExtraInfo: 'pointer'
});

const KEYBOARDINPUT = struct({
  wVk: 'uint16',
  wScan: 'uint16',
  dwFlags: 'uint32',
  time: 'uint32',
  dwExtraInfo: 'pointer'
})

const HARDWAREINPUT = struct({
  uMsg: 'uint32',
  wParamL: 'uint16',
  wParamH: 'uint16'
})

const INPUT_UNION = union({
	mi: MOUSEINPUT,
	ki: KEYBOARDINPUT,
	hi: HARDWAREINPUT
});

const INPUT = struct({
	type: 'uint32',
	dat: INPUT_UNION
});

// Assume we will always be runing on windows
let user32 = ffi.Library("user32.dll", {
	SendInput: ["uint32", ["uint32", INPUT, "int"]]
});

let keyInput = new KEYBOARDINPUT();
let inputUnion = new INPUT_UNION();
let input = new INPUT();

const keyTap = (keyString) => {
	let scanCode = keycodes.getKeyCode(keyString);
	
	if(scanCode == 0x00){
		console.log("[ERR] Invalid Keycode: " + keyString + "\n");
	}
	
	keyInput.wVk = scanCode;
	keyInput.wScan = 0;
	keyInput.dwFlags = 0x0000;
	keyInput.time = 0;
	keyInput.dwExtraInfo = ref.NULL_POINTER;
	
	inputUnion.ki = keyInput;
	
	input.type = 1;
	input.dat = inputUnion;
	
	user32.SendInput(1, input, INPUT.size);
	
	setTimeout(() => {
		keyInput.dwFlags = 0x0002;
		inputUnion.ki = keyInput;
		input.type = 1;
		input.dat = inputUnion;
		user32.SendInput(1, input, INPUT.size);
	}, 20);
}

module.exports = {keyTap};